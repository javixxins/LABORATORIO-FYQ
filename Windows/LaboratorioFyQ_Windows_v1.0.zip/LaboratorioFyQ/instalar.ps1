﻿# Instalador de Laboratorio FyQ para Windows
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Laboratorio FyQ'
Write-Host ''
Write-Host '  LABORATORIO FyQ 1.0 - Instalación' -ForegroundColor Cyan
Write-Host "  Carpeta del programa: $dest"
Write-Host ''
try {
  # cierra la app si está abierta (actualización)
  Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*Laboratorio FyQ*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Milliseconds 500
  foreach ($d in 'app','python') { $p = Join-Path $dest $d; if (Test-Path $p) { Remove-Item -Recurse -Force $p } }
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  Copy-Item -Recurse -Force (Join-Path $src 'app'), (Join-Path $src 'python') $dest
  foreach ($f in 'icono.ico','desinstalar.ps1','Tutorial_Laboratorio_FyQ.pdf') {
    $p = Join-Path $src $f; if (Test-Path $p) { Copy-Item -Force $p $dest }
  }
  Get-ChildItem -Recurse $dest | Unblock-File -ErrorAction SilentlyContinue

  $py     = Join-Path $dest 'python\pythonw.exe'
  $launch = Join-Path $dest 'app\launch.py'
  $ico    = Join-Path $dest 'icono.ico'
  $sh = New-Object -ComObject WScript.Shell
  $menu = [Environment]::GetFolderPath('Programs')
  foreach ($dir in @([Environment]::GetFolderPath('Desktop'), $menu)) {
    $l = $sh.CreateShortcut((Join-Path $dir 'Laboratorio FyQ.lnk'))
    $l.TargetPath = $py
    $l.Arguments = '"' + $launch + '" --instalado'
    $l.WorkingDirectory = Join-Path $dest 'app'
    $l.IconLocation = $ico
    $l.Description = 'Control de stock y viabilidad de prácticas de laboratorio'
    $l.Save()
  }
  $tut = Join-Path $dest 'Tutorial_Laboratorio_FyQ.pdf'
  if (Test-Path $tut) {
    $l = $sh.CreateShortcut((Join-Path $menu 'Laboratorio FyQ - Guía de uso.lnk')); $l.TargetPath = $tut; $l.Save()
  }

  # aparece en Configuración > Aplicaciones > Aplicaciones instaladas
  $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LaboratorioFyQ'
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty -Path $k -Name DisplayName     -Value 'Laboratorio FyQ'
  Set-ItemProperty -Path $k -Name DisplayVersion  -Value '1.0'
  Set-ItemProperty -Path $k -Name Publisher       -Value 'Departamento de Física y Química'
  Set-ItemProperty -Path $k -Name DisplayIcon     -Value $ico
  Set-ItemProperty -Path $k -Name InstallLocation -Value $dest
  Set-ItemProperty -Path $k -Name UninstallString -Value ('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $dest 'desinstalar.ps1') + '"')
  Set-ItemProperty -Path $k -Name NoModify -Value 1 -Type DWord
  Set-ItemProperty -Path $k -Name NoRepair -Value 1 -Type DWord

  Write-Host '  Instalación completada.' -ForegroundColor Green
  Write-Host '  Tienes el icono «Laboratorio FyQ» en el Escritorio y en el menú Inicio.'
  Write-Host '  Abriendo la aplicación en el navegador...'
  Start-Process -FilePath $py -ArgumentList ('"' + $launch + '" --instalado') -WorkingDirectory (Join-Path $dest 'app')
} catch {
  Write-Host ''
  Write-Host ('  ERROR: ' + $_.Exception.Message) -ForegroundColor Red
}
