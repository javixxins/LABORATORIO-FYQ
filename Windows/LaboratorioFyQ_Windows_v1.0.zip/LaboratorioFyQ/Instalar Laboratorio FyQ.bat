@echo off
title Instalar Laboratorio FyQ
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
