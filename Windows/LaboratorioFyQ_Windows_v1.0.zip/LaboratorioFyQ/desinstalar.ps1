﻿# Desinstalador de Laboratorio FyQ
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Laboratorio FyQ'
$datos = Join-Path $env:APPDATA 'Laboratorio FyQ'
Add-Type -AssemblyName System.Windows.Forms
$r = [System.Windows.Forms.MessageBox]::Show('¿Desinstalar Laboratorio FyQ?', 'Laboratorio FyQ', 'YesNo', 'Question')
if ($r -ne 'Yes') { exit }
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*Laboratorio FyQ*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 500
foreach ($l in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Laboratorio FyQ.lnk'),
                 (Join-Path ([Environment]::GetFolderPath('Programs')) 'Laboratorio FyQ.lnk'),
                 (Join-Path ([Environment]::GetFolderPath('Programs')) 'Laboratorio FyQ - Guía de uso.lnk'))) {
  if (Test-Path $l) { Remove-Item -Force $l }
}
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LaboratorioFyQ' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force $dest -ErrorAction SilentlyContinue
if (Test-Path $datos) {
  $r = [System.Windows.Forms.MessageBox]::Show("¿Borrar también tus datos (inventario, grupos y prácticas)?`n`nSi eliges «No» se conservan en:`n$datos", 'Laboratorio FyQ', 'YesNo', 'Warning')
  if ($r -eq 'Yes') { Remove-Item -Recurse -Force $datos -ErrorAction SilentlyContinue }
}
[System.Windows.Forms.MessageBox]::Show('Laboratorio FyQ se ha desinstalado.', 'Laboratorio FyQ') | Out-Null
